package com.spaceStation.app.Trackingapplication;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class TrackingapplicationApplication {

	public static void main(String[] args) {
		SpringApplication.run(TrackingapplicationApplication.class, args);
	}

}
