package com.spaceStation.app.Trackingapplication;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class TrackingapplicationApplicationTests {

	@Test
	void contextLoads() {
	}

}
